﻿namespace BlogSystem.Web.Infrastructure.Mapping
{
    public interface IMapFrom<T>
    {
    }
}