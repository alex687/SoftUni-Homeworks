﻿namespace MusicSystem.Client.Models.Albums
{
    public class AlbumSmallModel
    {
        public int Id { get; set; }

        public string Title { get; set; }

        public int Year { get; set; }

        public string Producer { get; set; }
    }
}