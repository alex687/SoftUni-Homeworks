function calcCircleArea(r){
    var result = r*r * Math.PI;
    document.body.innerHTML += "r= "+ r+ "; area =" + result+ "<br>";
}